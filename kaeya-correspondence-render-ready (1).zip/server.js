import express from "express";
import OpenAI from "openai";
import path from "node:path";
import { fileURLToPath } from "node:url";

const app = express();
const here = path.dirname(fileURLToPath(import.meta.url));
const port = process.env.PORT || 3000;

app.use(express.json({ limit: "40kb" }));
app.use(express.static(path.join(here, "public")));

const client = process.env.OPENAI_API_KEY
  ? new OpenAI({ apiKey: process.env.OPENAI_API_KEY })
  : null;

const persona = `You are roleplaying Kaeya Alberich from Genshin Impact in an immersive, ongoing private chat.
Stay recognisably in character: charming, witty, teasing, perceptive, socially skilled, occasionally flirtatious,
guarded about his own feelings, and capable of sincere tenderness when trust is earned. He is the Cavalry
Captain of the Knights of Favonius in Mondstadt. He often deflects with humour, notices more than he says,
and should not become a generic overly agreeable romantic chatbot. Keep his voice natural and conversational.
Use occasional subtle stage directions, not in every message. Never narrate the user's thoughts, feelings,
or actions for them. Do not decide their consent or speak on their behalf. Let relationship development
unfold gradually and respond to the user's chosen dynamic. Treat this as fictional roleplay; never claim to
be the real character or a real person. Avoid repeating the same greeting or pet name.`;

app.post("/api/chat", async (req, res) => {
  try {
    if (!client) {
      return res.status(503).json({ error: "The app needs an API key. Add OPENAI_API_KEY to your hosting environment." });
    }
    const { messages, relationship, tone, memory } = req.body || {};
    if (!Array.isArray(messages) || messages.length === 0 || messages.length > 24) {
      return res.status(400).json({ error: "Please send a valid recent chat history." });
    }
    const safeMessages = messages.slice(-20).map((m) => ({
      role: m.role === "assistant" ? "assistant" : "user",
      content: String(m.content || "").slice(0, 4000)
    }));
    const context = [
      `Relationship dynamic requested by the user: ${String(relationship || "Let it unfold naturally").slice(0, 160)}.`,
      `Conversation atmosphere: ${String(tone || "A little bit of everything").slice(0, 200)}.`,
      memory ? `User-approved continuity notes from earlier chats: ${String(memory).slice(0, 2500)}` : ""
    ].filter(Boolean).join("\n");

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5.5",
      instructions: `${persona}\n\nRoleplay settings:\n${context}`,
      input: safeMessages,
      max_output_tokens: 650
    });
    res.json({ reply: response.output_text || "Hm. It seems I've momentarily lost my words. Try that again?" });
  } catch (error) {
    console.error("Chat request failed:", error?.message || error);
    res.status(500).json({ error: "Kaeya couldn't reply just now. Please try again in a moment." });
  }
});

app.get("/{*splat}", (req, res) => {
  res.sendFile(path.join(here, "public", "index.html"));
});

app.listen(port, () => console.log(`Kaeya's Correspondence listening on ${port}`));
