const $ = (id) => document.getElementById(id);
const STORAGE = "kaeya-correspondence-v1";
const defaults = {
  messages: [],
  relationship: "Let it unfold naturally",
  tone: "A little bit of everything",
  memory: ""
};
let state = loadState();
let busy = false;

function loadState() {
  try { return { ...defaults, ...JSON.parse(localStorage.getItem(STORAGE) || "{}") }; }
  catch { return { ...defaults }; }
}
function saveState() {
  localStorage.setItem(STORAGE, JSON.stringify(state));
}
function escapeText(value) {
  return String(value).replace(/[&<>"']/g, c => ({ "&":"&amp;", "<":"&lt;", ">":"&gt;", '"':"&quot;", "'":"&#39;" }[c]));
}
function render() {
  const host = $("messages");
  host.innerHTML = "";
  const messages = state.messages.length ? state.messages : [{
    role: "assistant",
    content: "Well, well. There you are. I was beginning to think Mondstadt had become terribly dull without you. So, tell me… what’s on your mind tonight?"
  }];
  for (const msg of messages) {
    const user = msg.role === "user";
    const el = document.createElement("article");
    el.className = `message ${user ? "user" : "kaeya"}`;
    el.innerHTML = `<div class="avatar">${user ? "♡" : "K"}</div><div class="bubble-wrap"><div class="speaker">${user ? "YOU" : "KAEYA"}</div><div class="bubble">${escapeText(msg.content).replace(/\n/g,"<br>")}</div><time>${user ? "You" : "Kaeya"}</time></div>`;
    host.appendChild(el);
  }
  host.scrollTop = host.scrollHeight;
  window.scrollTo(0, document.body.scrollHeight);
}
function setBusy(value) {
  busy = value;
  $("typing").classList.toggle("hidden", !value);
  $("sendButton").disabled = value;
  $("messageInput").disabled = value;
}
async function sendMessage(text) {
  if (busy || !text.trim()) return;
  state.messages.push({ role: "user", content: text.trim() });
  saveState();
  $("messageInput").value = "";
  render();
  setBusy(true);
  try {
    const response = await fetch("/api/chat", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        messages: state.messages.slice(-20),
        relationship: state.relationship,
        tone: state.tone,
        memory: state.memory
      })
    });
    const data = await response.json();
    if (!response.ok) throw new Error(data.error || "Something went wrong.");
    state.messages.push({ role: "assistant", content: data.reply });
    saveState();
    render();
  } catch (error) {
    state.messages.push({ role: "assistant", content: `*A faintly apologetic smile.* It seems our correspondence has hit a small snag: ${error.message}` });
    saveState();
    render();
  } finally {
    setBusy(false);
    $("messageInput").focus();
  }
}

$("composer").addEventListener("submit", (event) => {
  event.preventDefault();
  sendMessage($("messageInput").value);
});
$("messageInput").addEventListener("keydown", (event) => {
  if (event.key === "Enter" && !event.shiftKey) {
    event.preventDefault();
    $("composer").requestSubmit();
  }
});
$("settingsOpen").addEventListener("click", () => {
  $("relationship").value = state.relationship;
  $("tone").value = state.tone;
  $("memory").value = state.memory;
  $("settings").showModal();
});
$("settings").addEventListener("submit", () => {
  state.relationship = $("relationship").value;
  state.tone = $("tone").value;
  state.memory = $("memory").value.trim();
  saveState();
});
$("clearChat").addEventListener("click", () => {
  if (confirm("Clear this conversation from this device? Your continuity notes will be kept.")) {
    state.messages = [];
    saveState();
    render();
    $("settings").close();
  }
});
if ("serviceWorker" in navigator) {
  window.addEventListener("load", () => navigator.serviceWorker.register("/sw.js").catch(() => {}));
}
render();
