# Kaeya's Correspondence

A mobile-friendly, installable PWA for an unofficial Kaeya Alberich roleplay chat.

## What is included

- Responsive chat interface with a Mondstadt-inspired night palette
- OpenAI Responses API backend (the API key stays on the server)
- Local chat history and editable continuity notes in the browser
- Relationship and tone settings
- PWA manifest, service worker and app icon

## Important

This is a fan-made, unofficial roleplay app and is not affiliated with HoYoverse. It is a source project, not a hosted service or an APK. To use it as a standalone app, deploy it to a hosting provider that supports Node.js and HTTPS. API usage is billed separately by the API provider; a ChatGPT subscription does not include API credit.

## Run locally

Requires Node.js 20 or newer.

1. Copy `.env.example` to `.env`.
2. Add your API key to `.env` as `OPENAI_API_KEY=...`.
3. Install dependencies: `npm install`
4. Start the server: `npm start`
5. Open `http://localhost:3000`

Do not commit `.env` or share your API key.

## Deploy and install on Android

1. Deploy this folder to a Node.js host that provides HTTPS and lets you set environment variables.
2. Set `OPENAI_API_KEY` in the host's private environment-variable settings. Optionally set `OPENAI_MODEL`.
3. Open the deployed HTTPS address in Chrome on Android.
4. Open Chrome's menu and choose **Install app** or **Add to Home screen**.

The chat and continuity notes are stored in that browser's local storage. Clearing browser site data will remove them. This starter version does not sync chats between devices or provide user accounts. For a public deployment, add authentication, request limits, and a database before sharing the app with others.
